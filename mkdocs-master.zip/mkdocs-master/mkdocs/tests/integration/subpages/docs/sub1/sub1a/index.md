# Test sub pages and referencing images

## Reference an image in: /sub1/

### Relative path

    ![Image](../image.png)

![Image](../image.png)

### Absolute path

    ![Image](/sub1/image.png)

![Image](/sub1/image.png)

## Reference an image in: /

### Relative path

    ![Image](../../image.png)

![Image](../../image.png)


### Absolute path

    ![Image](/image.png)

![Image](/image.png)
