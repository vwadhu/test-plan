# Complicated Config!

There is only one page, but the config is complicated and re-uses it many
times. It also aims to use every config in MkDocs.
